// Package v1alpha1 contains the core v1alpha1 API group
//
// +k8s:deepcopy-gen=package
// +groupName=core.haproxy.org
package v1alpha1
